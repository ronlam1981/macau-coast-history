import json
from shapely.geometry import Polygon,mapping
from shapely.ops import unary_union,transform
from shapely import make_valid
from pyproj import Transformer
x=json.load(open('query.txt')); grouped={}; excluded={}
t0=Transformer.from_crs(8433,4326,always_xy=True)
for f in x['features']:
 y=f['attributes']['YEAR'];parts=[]
 for r in f['geometry']['rings']:
  p=make_valid(Polygon(r));parts.append(p)
 # ArcGIS outer clockwise, holes counterclockwise. Symmetric difference handles containment.
 p=parts[0]
 for q in parts[1:]:p=p.symmetric_difference(q)
 lon,lat=t0.transform(p.centroid.x,p.centroid.y)
 if 113.53<lon<113.549 and 22.12<lat<22.14 and p.area>100000:
  excluded.setdefault(y,[]).append(p)
 else: grouped.setdefault(y,[]).append(p)
t=Transformer.from_crs(8433,4326,always_xy=True)
lands={y:unary_union(v).buffer(0).simplify(1.5,preserve_topology=True) for y,v in grouped.items()}
out={'years':sorted(lands),'land':{},'added':{},'areas':{},'source':'DSSCU EVOL evol_v2, fetched 2026-10-29','comparisonYear':max(lands)}
out['excluded']=mapping(transform(t.transform,unary_union(excluded[max(excluded)])))
for y,p in sorted(lands.items()):
 print(y,round(p.area/1e6,3),p.bounds)
 out['land'][y]=mapping(transform(t.transform,p));out['added'][y]=mapping(transform(t.transform,lands[max(lands)].difference(p)));out['areas'][y]=round(p.area/1e6,3)
json.dump(out,open('/workspace/sites/macau-coast-history/dist/assets/coast.json','w'),separators=(',',':'))

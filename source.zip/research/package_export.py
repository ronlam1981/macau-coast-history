from pathlib import Path
import json,base64,re
root=Path('/workspace/sites/macau-coast-history/dist')
p=root/'assets/coast.json';d=json.loads(p.read_text())
def rounded(v):
 if isinstance(v,float):return round(v,7)
 if isinstance(v,list):return [rounded(x) for x in v]
 if isinstance(v,dict):return {k:rounded(x) for k,x in v.items()}
 return v
d=rounded(d);p.write_text(json.dumps(d,separators=(',',':')))
# Fully self-contained downloadable HTML retains the local maps when opened offline.
s=(root/'index.html').read_text();s=s.replace('<link rel="stylesheet" href="assets/leaflet.css">','<style>'+(root/'assets/leaflet.css').read_text()+'</style>')
s=s.replace('<script src="assets/leaflet.js"></script>','<script>'+(root/'assets/leaflet.js').read_text().replace('</script','<\\/script')+'</script>')
js=(root/'app.js').read_text();js=js.replace("const data=await (await fetch('assets/coast.json')).json();",'const data='+json.dumps(d,separators=(',',':'))+';').replace("const maps=await (await fetch('assets/maps.json')).json();",'const maps='+(root/'assets/maps.json').read_text()+';')
imgs={p.stem:'data:image/webp;base64,'+base64.b64encode(p.read_bytes()).decode() for p in (root/'assets').glob('*.webp')}
js='const embeddedAssets='+json.dumps(imgs,separators=(',',':'))+';\n'+js
js=js.replace('`assets/${id}.webp`','embeddedAssets[id]').replace('`assets/${s.id}.webp`','embeddedAssets[s.id]')
s=s.replace('<script src="app.js"></script>','<script>'+js.replace('</script','<\\/script')+'</script>')
for f,mime in [('assets/coast.json','application/json'),('assets/SOURCES.txt','text/plain')]:s=s.replace('href="'+f+'"','href="data:'+mime+';base64,'+base64.b64encode((root/f).read_bytes()).decode()+'"')
s=s.replace(' · <a href="macau-coast-comparison.html" download>下載單檔互動地圖</a>','')
(root/'macau-coast-comparison.html').write_text(s)
# Reproducible processing source is retained with the Site repository.
for f in ['build_coasts.py','fetch_maps.py','package_export.py']:
 q=Path(f)
 if q.exists():
  dst=root.parent/'research';dst.mkdir(exist_ok=True);(dst/f).write_bytes(q.read_bytes())
print('Standalone export',round(len(s.encode())/1e6,2),'MB; coast years',len(d['years']))

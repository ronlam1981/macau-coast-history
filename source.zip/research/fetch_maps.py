import math,io,json,urllib.request,concurrent.futures,time,os,xml.etree.ElementTree as E
from PIL import Image
root='/workspace/sites/macau-coast-history/dist/assets/'
ns={'w':'http://www.opengis.net/wmts/1.0','o':'http://www.opengis.net/ows/1.1'}
r=E.parse('wmts.txt');jobs=[];meta=[]
def xy(lon,lat,z):return ((lon+180)/360*2**z,(1-math.asinh(math.tan(math.radians(lat)))/math.pi)/2*2**z)
def ll(x,y,z):return [math.degrees(math.atan(math.sinh(math.pi*(1-2*y/2**z)))),x/2**z*360-180]
for l in r.findall('.//w:Layer',ns):
 id=l.find('o:Identifier',ns).text
 lo=list(map(float,l.find('o:WGS84BoundingBox/o:LowerCorner',ns).text.split()));hi=list(map(float,l.find('o:WGS84BoundingBox/o:UpperCorner',ns).text.split()))
 b=[max(113.515,lo[0]),max(22.105,lo[1]),min(113.615,hi[0]),min(22.23,hi[1])]
 z=14 if id=='Macau_7K_1945' else 13
 meta.append({'id':id,'title':l.find('o:Title',ns).text,'coverage':[[lo[1],lo[0]],[hi[1],hi[0]]],'zoom':z,'b':b,'url':l.find('w:ResourceURL',ns).attrib['template']})
meta += [{'id':'streets','title':'OpenStreetMap 街道','zoom':14,'b':[113.515,22.105,113.615,22.23],'url':'https://tile.openstreetmap.org/{TileMatrix}/{TileCol}/{TileRow}.png'},{'id':'satellite','title':'Esri World Imagery','zoom':14,'b':[113.515,22.105,113.615,22.23],'url':'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{TileMatrix}/{TileRow}/{TileCol}'}]
for m in meta:
 z=m['zoom'];w,s,e,n=m['b'];x0,y0=map(math.floor,xy(w,n,z));x1,y1=map(math.floor,xy(e,s,z));m.update(x0=x0,y0=y0,x1=x1,y1=y1,bounds=[ll(x0,y1+1,z),ll(x1+1,y0,z)],tiles={})
 for x in range(x0,x1+1):
  for y in range(y0,y1+1):jobs.append((m,x,y))
def fetch(job):
 m,x,y=job;u=m['url'].replace('{TileMatrix}',str(m['zoom'])).replace('{TileCol}',str(x)).replace('{TileRow}',str(y))
 for retry in range(2):
  try:
   req=urllib.request.Request(u,headers={'User-Agent':'MacauCoastComparison/1.0 (historical map research)'})
   b=urllib.request.urlopen(req,timeout=20).read();im=Image.open(io.BytesIO(b)).convert('RGBA');m['tiles'][x,y]=im;return
  except Exception as ex:
   if retry==1:print('FAIL',m['id'],x,y,str(ex),flush=True)
print('Downloading',len(jobs),'tiles',flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=16) as pool:
 for i,_ in enumerate(pool.map(fetch,jobs)):
  if i%30==0:print('processed',i,flush=True)
for m in meta:
 im=Image.new('RGBA',((m['x1']-m['x0']+1)*256,(m['y1']-m['y0']+1)*256))
 for (x,y),tile in m['tiles'].items():im.paste(tile,((x-m['x0'])*256,(y-m['y0'])*256))
 im.save(root+m['id']+'.webp',quality=86);m['loaded']=len(m['tiles']);del m['tiles'];print('saved',m['id'],m['loaded'],flush=True)
json.dump(meta,open(root+'maps.json','w'),ensure_ascii=False)
